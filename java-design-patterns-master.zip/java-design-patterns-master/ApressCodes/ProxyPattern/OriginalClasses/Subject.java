package OriginalClasses;

public abstract class Subject
{
    public abstract void doSomeWork();
}
