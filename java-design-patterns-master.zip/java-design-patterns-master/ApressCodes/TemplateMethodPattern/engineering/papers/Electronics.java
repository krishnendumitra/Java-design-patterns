package engineering.papers;

public class Electronics extends BasicEngineering
{
	@Override
    public void SpecialPaper()
    {
		 System.out.println("Digital Logic and Circuit Theory");
    }
}